# _*_ coding: utf-8 _*_
__author__ = 'Kris <criselyj@163.com>'
__version__ = '1.0.0'
__site__ = 'https://github.com/Kr1s77/FgSurfing'
